This submission contains results for the word-level and sentence-level morpheme segmentation shared tasks at SIGMORPHON 2022.
Results for word-level segmentation (all languages) are in folder 'word-level'.
Results for sentence-level segmentation (all languages) are in folder 'sentence-level'.
We only submit one set of predictions for each language/subtask.

Predictions are stored in tsv files.
The format is: Input sting TAB Predicted morphemes

Leander Girrbach, University of Tübingen
